<p align="center">
    <img src="assets/logo_infnet.png" width="70" height="70" />
</p>

# Teste de Performance 1

## Ponto de Partida

Esse é o primeiro teste de performance (TP) da disciplina regular "Programação Web com HTML5 e CSS3" do Bloco "Fundamentos do Desenvolvimento de Software", o Bloco de Entrada da sua graduação. É a partir daqui que você irá dar seus primeiros passos em sua formação. 

Nesse TP1, temos como objetivo desenvolver a primeira parte da  competência prevista para nossa disciplina: _Criar primeiras páginas web em HTML5 e CSS3 usando uma IDE "code playground"_ . (Ainda não entendeu o que são competências e rúbricas? não tem problema, preparamos um texto explicativo no [Manual do aluno](https://sites.google.com/infnet.edu.br/manualgrad/modelo-de-ensino/compet%C3%AAncias-e-rubricas?authuser=0)) Para tal, você irá desenvolver 10 exercícios que irão passar por todo o conteúdo visto na primeira etapa do curso. 

Leia as instruções em todos exercícios com atenção e faça um bom trabalho! Mãos à obra!