<p align="center">
    <img src="assets/logo_infnet.png" width="70" height="70" />
</p>

# Teste de Performance 1

## Exercício 2

O primeiro exercício foi muito fácil!! Vamos fazer algo com um alcance um pouco maior??? Se no exercício anterior a gente disse "Olá Mundo!", nesse exercício iremos escrever uma carta para ser acessada pelos futuros habitantes de Marte. Para tal, criaremos uma página Web, usando as tags \<p\> e \<br\>, que são usadas para criar parágrafos e quebras de linha.

Essa carta precisa ter 3 parágrafos. No primeiro, você irá se apresentar. No segundo, você irá escrever alguma coisa relevante sobre o planeta Terra. O último parágrafo, pergunte como estão as coisas em Marte.

Por fim, quebre 2 linhas e finalize a carta escrevendo "Saudações terráqueas", quebre mais uma linha e escreva seu nome.