<p align="center">
    <img src="assets/logo_infnet.png" width="70" height="70" />
</p>

# Teste de Performance 1

## Exercício 8



Verifique no código, todos os erros que você consegue encontrar e os corrija!