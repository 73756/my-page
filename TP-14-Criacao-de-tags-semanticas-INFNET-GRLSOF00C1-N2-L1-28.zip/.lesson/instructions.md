<p align="center">
    <img src="assets/logo_infnet.png" width="70" height="70" />
</p>

# Teste de Performance 1

## Exercício 4

Você pode utilizar a tag `<header>` de diversas maneiras. No uso mais comum, apresenta informações introdutórias do início da página (cabeçalhos, imagens de logo ou contêiners).


Nesse exercício crie um header que contenha:

* Cabeçalho escrito `Instituto Infnet`
* O texto
  
> O Instituto Infnet é a maior faculdade de tecnologia do Rio de Janeiro, com mais de 27 anos de história e mais de 20 mil alunos formados"

dentro dentro de uma tag `<p>`

* Coloque o título da página igual à `Instituto Infnet`