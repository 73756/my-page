<p align="center">
    <img src="assets/logo_infnet.png" width="70" height="70" />
</p>

# Teste de Performance 1

## Exercício 9

Escreva o conteúdo da página e depois escolha as tags mais semânticas que você lembrar para cada parte do conteúdo.

O rodapé deve conter as seguintes informações:

Uma seção com título "Correspondência" contendo:
- o horário para recebimento de correspondências
- um endereço para correspondência com:
    - Nome da empresa
    - Rua, núemro e andar
    - Bairro
    - Cidade - estado

Uma seção com título "Telefones" contendo:
- o horário para recebimento de ligações
- Telefone de Pessoa Física
- Telefone de Pessoa Jurídica


### Conteúdo da página

* ((todos os dias, das 9h às 18h)
* AOVS Sistemas de Informática S.A
* Rua Vergueiro, 3185, 8º andar
* Vila Mariana
* São Paulo - SP
* Telefones (segunda à sexta, das 9h às 18h)
    * Pessoa Física: (11) 4118-3319
    * Pessoa Jurídica: (11) 4118-2172